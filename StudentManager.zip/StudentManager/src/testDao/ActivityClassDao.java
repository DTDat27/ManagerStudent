package testDao;

import java.util.List;

import entity.ActivityClass;

public interface ActivityClassDao {
	public List<ActivityClass> getListClass();
}
