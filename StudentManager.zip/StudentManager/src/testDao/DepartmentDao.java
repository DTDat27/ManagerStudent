package testDao;

import java.util.List;

import entity.Department;

public interface DepartmentDao {
	public List<Department> getListDepartment();
}
