package entity;

public class ActivityClass extends University {

}
