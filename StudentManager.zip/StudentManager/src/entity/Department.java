package entity;

public class Department extends University {

}
